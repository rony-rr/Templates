// MAIN JS
jQuery(document).ready(function($) {

    /**
     * 
     * FRONTEND CUSTOM JS SCRIPT ADD LIBS
     * 
    */

    var formData = {
        'action' : 'get_ajax_method',
        'item' : 'value',
    };
    
    $.ajax({
        url: twenty_ajax.ajaxurl,
        type: 'POST',
        data: formData,

        beforeSend: function(){
            console.log('Loading...');           
        },
        success: function( response ) {
            console.log(response);
        },
        error: function(response) {
            console.log('error');
        },
        complete: function( data ){
            console.log('complete');
        }
    }).done(function(data) {
        console.log('done');
    }).fail(function(data) {
        console.log('fail');
    });

});