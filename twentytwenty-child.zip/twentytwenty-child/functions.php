<?php 


    /**
     * Load the parent & child theme styles
    */

    /**
     * Enqueue style of child theme
    */
    function twenty_child_enqueue_styles() {

        // To Posts & PostTypes
        global $wp;
        global $post;

        wp_enqueue_style( 'twenty-child-style', get_template_directory_uri() . '/style.css' ); 
        wp_enqueue_script( 'twenty-child-custom-scripts', get_template_directory_uri() . '/public/js-scripts/lib.custom-scripts.js' );

        // To Frontend AJAX Request
        wp_localize_script( 'twenty-child-custom-scripts', 'twenty_ajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );

    }
    add_action( 'wp_enqueue_scripts', 'twenty_child_enqueue_styles', 100000 );


    // Call to AJAX Fcuntion in action hook WP API
    //Actions
    add_action( "wp_ajax_get_ajax_method", "getResults_wp_ajax_function" );
    add_action( "wp_ajax_nopriv_get_ajax_method", "getResults_wp_ajax_function" );

    function getResults_wp_ajax_function(){
        echo 1;
    }



?>