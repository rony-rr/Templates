<?php
/*
    Plugin Name: Plugin1
    Plugin URI: 
    Description: Plugin by Rony Santos.
    Version: 1.0.0
    Author: Rony Santos.
    Author URI: 
    License: GPL2
    Text Domain: plugin-1
*/

    include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

    function plugin1_install() {
    
        global $wpdb;
        global $jal_db_version;
  
        // Cotejamiento para la BDD
        $charset_collate = $wpdb->get_charset_collate();
  
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        add_option( 'jal_db_version', $jal_db_version );   
  
    }
    register_activation_hook( __FILE__, 'plugin1_install' );


    // creación del Menú y componentes.
    add_action('admin_menu', 'plugin1_menu');
    function plugin1_menu()
    {
        add_menu_page('Plugin1', 'Plugin1', 'manage_options', 'plugin1_main', 'plugin1_main', 'dashicons-editor-spellcheck');
        add_submenu_page( 'plugin1_main', 'Options', 'Options', 'manage_options', 'plugin1_page_1', 'plugin1_page_1');
        
    }

    // función main del plugin
    function plugin1_main(){

        echo 'Main menú';
    }

    function plugin1_page_1(){
        echo 'Page 1';
    }

?>